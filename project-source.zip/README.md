# AI-Driven Gearbox Fault Diagnostic Rig

Embedded acquisition and motor-control components from a multidisciplinary rig that classifies healthy, chipped-tooth, and missing-tooth gearbox conditions.

## Technologies

Arduino / ESP32 / vibration sensing

## Explore the project

The available code covers accelerometer acquisition and VFD control. The PC diagnostic application and trained model are not in the supplied folder.

## Files

- `docs/TEAM_M049_Final_Report.md`
- `Accelerometors_Continous_Reading/sketch_apr17a/sketch_apr17a.ino`
- `VFD_Control_stope_start_with_shutdown/sketch_apr18a/sketch_apr18a.ino`

## Project context

Academic project: Senior Design. These are archival portfolio files; builds and hardware behavior have not been revalidated. Team projects retain contributor names where available; individual ownership of all components is not implied.

Reports are provided as extracted text. Original images, formatting, signatures, student IDs, duplicate archives, and large demo files are omitted.
